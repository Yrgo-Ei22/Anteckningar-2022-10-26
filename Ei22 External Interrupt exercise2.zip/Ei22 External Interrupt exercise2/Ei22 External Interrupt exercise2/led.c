/********************************************************************************
* led.c: Funktionsdefinitioner f�r styrning av lysdioderna.
********************************************************************************/
#include "header.h"

/* Statiska funktioner: */
static void delay_ms(const volatile uint16_t* delay_time_ms);

/* Statiska datamedlemmar: */
static bool led1_enabled = false; /* Indikerar ifall lysdiod 1 �r t�nd. */
static uint16_t speed_ms = 0;     /* Lagrar lysdiodens blinkhastighet. */

/********************************************************************************
* led_toggle: Togglar lysdiod p� I/O-port B mellan att vara t�nd eller sl�ckt.
*             Vid sl�ckning nollst�lls lysdiodens blinkhastighet f�r att direkt
*             avsluta eventuell blinkning.
*
*             - pin: Lysdiodens pin-nummer p� I/O-port B.
********************************************************************************/
void led_toggle(const uint8_t pin)
{
   if (pin == LED1) 
   {
      led1_enabled = !led1_enabled;

      if (!led1_enabled) 
      {
         LED1_OFF;
         speed_ms = 0; 
      }
   }

   return;
}

/********************************************************************************
* led_blink: Blinkar lysdiod p� I/O-port B med angiven blinkhastighet,
*            f�rutsatt att denna �r aktiverad.
*
*            - pin: Lysdiodens pin-nummer p� I/O-port B.
*            - blink_speed_ms: Blinkhastigheten m�tt i millisekunder.
********************************************************************************/
void led_blink(const uint8_t pin,
               const uint16_t blink_speed_ms)
{
   if (led1_enabled)
   {
      speed_ms = blink_speed_ms; 
      PORTB |= (1 << pin);
      delay_ms(&speed_ms);
      PORTB &= ~(1 << pin);
      delay_ms(&speed_ms);
   }

   return;
}

/********************************************************************************
* delay_ms: Genererar f�rdr�jning m�tt i millisekunder.
*
*           - delay_time_ms: Pekare till minnesadress inneh�llande angiven
*                            f�rdr�jningstid i millisekunder.
********************************************************************************/
static void delay_ms(const volatile uint16_t* delay_time_ms) 
{
   for (uint16_t i = 0; i < *delay_time_ms; ++i)
   {
      _delay_ms(1);
   }

   return;
}