/********************************************************************************
* setup.c: Inneh�ller diverse initieringsrutiner.
********************************************************************************/
#include "header.h"

/* Statiska funktioner: */
static inline void init_ports(void);
static inline void init_interrupts(void);

/********************************************************************************
* setup: Initierar det inbyggda systemet genom att konfigurera I/O-portar samt
*        aktivera externt avbrott INT0.
********************************************************************************/
void setup(void)
{
   init_ports();
   init_interrupts();
   return;
}

/********************************************************************************
* init_ports: Konfigurerar I/O-portar genom att s�tta lysdiodens pin till utport
*             och aktivera den interna pullup-resistorn p� tryckknappens pin.
********************************************************************************/
static inline void init_ports(void)
{
   DDRB = (1 << LED1);
   PORTD = (1 << BUTTON1);
   return;
}

/********************************************************************************
* init_interrupts: Aktiverar externt avbrott INT0 p� stigande flank.
********************************************************************************/
static inline void init_interrupts(void)
{
   asm("SEI"); 
   EICRA = (1 << ISC01) | (1 << ISC00); 
   EIMSK = (1 << INT0); 
   return;
}