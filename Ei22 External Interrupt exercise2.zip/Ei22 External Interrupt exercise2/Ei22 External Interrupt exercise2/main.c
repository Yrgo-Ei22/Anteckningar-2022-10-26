/********************************************************************************
* main.c: Implementering av ett inbyggt system inneh�llande en lysdiod ansluten
*         till pin 8 (PORTB0) samt en tryckknapp ansluten till pin 2 (PORTD2).
*         Externt avbrott INT0 aktiveras p� tryckknappens pin f�r att toggla 
*         lysdioden mellan att blinka var 100:e milliseknd samt vara sl�ckt. 
********************************************************************************/
#include "header.h"

/********************************************************************************
* INT0_vect: Avbrottsrutin som �ger rum vid nedtryckning av tryckknappen
*            ansluten till pin 2 (PORTD2), vilket medf�r toggling av lysdioden
*            ansluten till pin 8 (PORTB0).
********************************************************************************/
ISR (INT0_vect)
{
   led_toggle(LED1);
   return;
}

/********************************************************************************
* main: Initierar mikrodatorn vid start. Om lysdioden �r aktiverad blinkar
*       denna var 100:e millisekund, annars h�lls den sl�ckt.
********************************************************************************/
int main(void)
{
   setup(); 

   while (1)
   {
      led_blink(LED1, 100);
   }

   return 0;
}

