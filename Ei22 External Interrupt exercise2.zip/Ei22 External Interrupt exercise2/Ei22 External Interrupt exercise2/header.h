/********************************************************************************
* header.h: Inneh�ller diverse deklarationer och definitioner f�r implementering
*           av det inbyggda systemet.
********************************************************************************/
#ifndef HEADER_H_
#define HEADER_H_

/* Klockfrekvens (beh�vs f�r f�rdr�jningsrutiner): */
#define F_CPU 16000000UL /* 16 MHz. */

/* Inkluderingsdirektiv: */
#include <avr/io.h>        /* Inneh�ller information om I/O-portar, s�som DDRB och PORTB. */
#include <avr/interrupt.h> /* Inneh�ller information om avbrottsvektorer, s�som INT0_vect. */
#include <util/delay.h>    /* Inneh�ller f�rdr�jningsrutiner. */

/* Makrodefinitioner: */
#define LED1 0    /* Lysdiod 1 ansluten till pin 8 / PORTB0. */
#define BUTTON1 2 /* Tryckknapp 1 ansluten till pin 2 / PORTD2. */

#define LED1_ON PORTB |= (1 << LED1)    /* T�nder lysdiod 1. */
#define LED1_OFF PORTB &= ~(1 << LED1)  /* Sl�cker lysdiod 1. */

#define BUTTON1_IS_PRESSED (PIND & (1 << BUTTON1)) /* Indikerar nedtryckning av tryckknapp 1. */

/* Enumerationer: */
typedef enum { false, true } bool; /* Realiserar datatypen bool. */

/********************************************************************************
* setup: Initierar det inbyggda systemet genom att konfigurera I/O-portar samt
*        aktivera externt avbrott INT0.
********************************************************************************/
void setup(void);

/********************************************************************************
* led_toggle: Togglar lysdiod p� I/O-port B mellan att vara t�nd eller sl�ckt.
*             Vid sl�ckning nollst�lls lysdiodens blinkhastighet f�r att direkt
*             avsluta eventuell blinkning.
*
*             - pin: Lysdiodens pin-nummer p� I/O-port B.
********************************************************************************/
void led_toggle(const uint8_t pin);

/********************************************************************************
* led_blink: Blinkar lysdiod p� I/O-port B med angiven blinkhastighet,
*            f�rutsatt att denna �r aktiverad.
*
*            - pin: Lysdiodens pin-nummer p� I/O-port B.
*            - blink_speed_ms: Blinkhastigheten m�tt i millisekunder.
********************************************************************************/
void led_blink(const uint8_t pin,
               const uint16_t blink_speed_ms);

#endif /* HEADER_H_ */